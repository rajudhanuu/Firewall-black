package com.firewall.black

import android.net.VpnService
import android.content.Intent
import android.os.IBinder

/**
 * Deliberately safe scaffold. It does not establish a TUN interface yet.
 * Do not establish a default route until a complete packet engine is integrated.
 */
class FirewallVpnService : VpnService() {
    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // TODO: Implement a foreground notification and packet engine before
        // establishing a VPN interface. This scaffold does not filter traffic.
        stopSelf()
        return START_NOT_STICKY
    }
}
