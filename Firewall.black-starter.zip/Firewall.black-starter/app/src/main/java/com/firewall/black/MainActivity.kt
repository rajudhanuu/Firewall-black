package com.firewall.black

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val rules = mutableListOf(
        FirewallRule(
            action = RuleAction.BLOCK,
            destinationIp = "203.0.113.10",
            protocol = NetworkProtocol.TCP,
            destinationPort = 443
        )
    )
    private lateinit var ruleList: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(Color.rgb(12, 12, 16))
        }
        root.addView(TextView(this).apply {
            text = "Firewall.black"
            textSize = 28f
            setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = "ADVANCED RULES  •  PROTOTYPE"
            textSize = 12f
            setTextColor(Color.rgb(80, 220, 160))
            setPadding(0, 8, 0, 20)
        })
        root.addView(TextView(this).apply {
            text = "Rule engine demo only. Live traffic is NOT filtered yet."
            textSize = 14f
            setTextColor(Color.rgb(255, 190, 90))
            setPadding(0, 0, 0, 16)
        })

        val ipInput = EditText(this).apply {
            hint = "Destination IP (or *)"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        root.addView(ipInput, matchWrap())

        val protocol = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                NetworkProtocol.values().map { it.name }
            )
        }
        root.addView(protocol, matchWrap())

        val portInput = EditText(this).apply {
            hint = "Destination port (optional)"
            inputType = 2
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        root.addView(portInput, matchWrap())

        val action = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                RuleAction.values().map { it.name }
            )
        }
        root.addView(action, matchWrap())

        root.addView(Button(this).apply {
            text = "Add rule"
            setOnClickListener {
                val ip = ipInput.text.toString().trim().ifBlank { "*" }
                val portText = portInput.text.toString().trim()
                val port = if (portText.isBlank()) null else portText.toIntOrNull()
                if (portText.isNotBlank() && (port == null || port !in 1..65535)) {
                    Toast.makeText(this@MainActivity, "Port must be 1–65535", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                try {
                    rules.add(0, FirewallRule(
                        action = RuleAction.valueOf(action.selectedItem.toString()),
                        destinationIp = ip,
                        protocol = NetworkProtocol.valueOf(protocol.selectedItem.toString()),
                        destinationPort = port
                    ))
                    refreshRules()
                    Toast.makeText(this@MainActivity, "Rule added to demo list", Toast.LENGTH_SHORT).show()
                } catch (e: IllegalArgumentException) {
                    Toast.makeText(this@MainActivity, "Enter a valid IP address or *", Toast.LENGTH_SHORT).show()
                }
            }
        }, matchWrap())

        ruleList = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 18, 0, 0)
        }
        root.addView(ScrollView(this).apply { addView(ruleList) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        refreshRules()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 8 }

    private fun refreshRules() {
        ruleList.text = if (rules.isEmpty()) "No rules yet." else rules.mapIndexed { i, r ->
            "${i + 1}. ${r.action}  ${r.protocol}  ${r.destinationIp}:${r.destinationPort ?: "*"}"
        }.joinToString("\n\n")
    }
}
