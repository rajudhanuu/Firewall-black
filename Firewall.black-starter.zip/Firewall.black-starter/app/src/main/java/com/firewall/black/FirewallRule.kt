package com.firewall.black

enum class RuleAction { ALLOW, BLOCK }
enum class NetworkProtocol { ANY, TCP, UDP }

data class FirewallRule(
    val action: RuleAction,
    val destinationIp: String = "*",
    val protocol: NetworkProtocol = NetworkProtocol.ANY,
    val destinationPort: Int? = null,
    val enabled: Boolean = true
) {
    init {
        require(destinationPort == null || destinationPort in 1..65535) {
            "Port must be between 1 and 65535"
        }
        require(destinationIp == "*" || destinationIp.matches(Regex("[0-9a-fA-F:.]+"))) {
            "Use an IPv4/IPv6 address or *"
        }
    }

    fun matches(ip: String, proto: NetworkProtocol, port: Int): Boolean =
        enabled &&
        (destinationIp == "*" || destinationIp.equals(ip, ignoreCase = true)) &&
        (protocol == NetworkProtocol.ANY || protocol == proto) &&
        (destinationPort == null || destinationPort == port)
}

object RuleEngine {
    /** First matching rule wins. No match returns the supplied default action. */
    fun decide(
        rules: List<FirewallRule>,
        ip: String,
        protocol: NetworkProtocol,
        port: Int,
        defaultAction: RuleAction = RuleAction.BLOCK
    ): RuleAction = rules.firstOrNull { it.matches(ip, protocol, port) }?.action
        ?: defaultAction
}
