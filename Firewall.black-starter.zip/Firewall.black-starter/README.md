# Firewall.black — Android starter

This is a **starter prototype**, not a complete traffic-filtering firewall. It includes a native Kotlin app, a custom IP/protocol/port rule model and matcher, a basic rule-entry screen, and a VPN service scaffold.

**Safety:** The VPN service intentionally does not establish a VPN interface or redirect traffic. A real VPN firewall needs a tested packet engine for TCP/UDP, IPv4/IPv6, DNS, routing, and forwarding. Do not claim protection until that engine is implemented and tested.

## Build on an Android phone

1. Install an Android IDE that supports Kotlin and Gradle on your phone, or use an Android-compatible cloud IDE in your browser.
2. Create/open a Gradle Android project using package `com.firewall.black`.
3. Copy these files into the matching paths.
4. Use Android Gradle Plugin 8.5+ and Kotlin 2.0+ (or adapt versions to your IDE).
5. Sync/build the project, then install the debug APK.
6. Test rule matching in the app. This prototype does **not** filter live network traffic.

## Next engineering milestones

1. Persist rules with Room/DataStore.
2. Add per-app rules using `VpnService.Builder.addAllowedApplication()` / `addDisallowedApplication()` where appropriate.
3. Integrate a maintained, audited userspace packet engine or implement packet parsing and forwarding correctly.
4. Add DNS and IPv6 handling, foreground-service notification, network-change recovery, and leak tests.
5. Test on Wi-Fi and mobile data before describing it as a firewall.

Never add a default route to a TUN interface until packet forwarding is implemented; otherwise connectivity can be lost.
